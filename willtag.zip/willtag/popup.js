// ============================================================
// Willtag · Organização Visual | popup.js  v4.0
// Alterações v4.0:
//  - Nome da extensão: Organização Visual - Willtag (sem TJPB)
//  - Aba "Prazos" com contadores expirados
//  - Opções rápidas de limite: 5, 15, 30, 90 dias
//  - Export/Import inclui reusData (contadores e URLs)
//  - Botão de ordem corrigida no layout
// ============================================================

const STORAGE_KEY  = 'pjeTags_v3';
const PALETTE_KEY  = 'pjeTags_palette';
const ENABLED_KEY  = 'pjeTags_enabled';
const REUS_KEY     = 'pjeTags_reus';

// ── Utilitários ──────────────────────────────────────────────

function contrastColor(hex) {
  const r=parseInt(hex.slice(1,3),16), g=parseInt(hex.slice(3,5),16), b=parseInt(hex.slice(5,7),16);
  return ((0.299*r+0.587*g+0.114*b)/255)>0.55?'#1a1a2e':'#ffffff';
}

function diasDecorridos(dataInicio) {
  if (!dataInicio) return null;
  const a=new Date(dataInicio), b=new Date();
  a.setHours(0,0,0,0); b.setHours(0,0,0,0);
  return Math.floor((b-a)/86400000);
}

function validateUrl(raw) {
  if (!raw.trim()) return null;
  let u = raw.trim();
  if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
  try { new URL(u); return u; } catch { return null; }
}

// ── Tabs ─────────────────────────────────────────────────────

document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(s => s.classList.remove('active'));
    btn.classList.add('active');
    const id = 'tab-' + btn.getAttribute('data-tab');
    document.getElementById(id)?.classList.add('active');
    if (btn.getAttribute('data-tab') === 'dados') renderDados();
    if (btn.getAttribute('data-tab') === 'prazos') renderPrazos();
  });
});

// ── Toggle enabled ───────────────────────────────────────────

const toggleEl    = document.getElementById('toggle-enabled');
const toggleLabel = document.getElementById('toggle-label');
const disabledBan = document.getElementById('disabled-banner');
const appEl       = document.getElementById('app');

chrome.storage.local.get(ENABLED_KEY, r => {
  const en = r[ENABLED_KEY] !== false;
  toggleEl.checked = en;
  updateEnabledUI(en);
});

toggleEl.addEventListener('change', () => {
  const en = toggleEl.checked;
  chrome.storage.local.set({ [ENABLED_KEY]: en });
  updateEnabledUI(en);
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { type: 'SET_ENABLED', value: en }).catch(() => {});
  });
});

function updateEnabledUI(en) {
  toggleLabel.textContent = en ? 'Ativa' : 'Pausada';
  disabledBan.style.display = en ? 'none' : 'flex';
  appEl.classList.toggle('app-disabled', !en);
}

document.getElementById('btn-reenable').addEventListener('click', () => {
  toggleEl.checked = true;
  chrome.storage.local.set({ [ENABLED_KEY]: true });
  updateEnabledUI(true);
});

// ── Refresh button ───────────────────────────────────────────

document.getElementById('btn-refresh').addEventListener('click', () => {
  const btn = document.getElementById('btn-refresh');
  btn.classList.add('refreshing');
  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    if (!tabs[0]) { btn.classList.remove('refreshing'); return; }
    chrome.tabs.sendMessage(tabs[0].id, { type: 'REFRESH_NOW' }, () => {
      btn.classList.remove('refreshing');
    });
  });
});

// ── Color presets ─────────────────────────────────────────────

document.querySelectorAll('.color-dot').forEach(dot => {
  dot.addEventListener('click', () => {
    document.getElementById('tag-color').value = dot.getAttribute('data-color');
    document.querySelectorAll('.color-dot').forEach(d => d.classList.remove('selected'));
    dot.classList.add('selected');
    updatePreview();
  });
});

// ── Live preview ──────────────────────────────────────────────

function updatePreview() {
  const name  = document.getElementById('tag-name').value.trim() || 'Audiência';
  const color = document.getElementById('tag-color').value;
  const url   = document.getElementById('tag-url').value.trim();
  const prev  = document.getElementById('tag-preview');
  const hint  = document.getElementById('url-hint');

  prev.textContent = name;
  prev.style.backgroundColor = color;
  prev.style.color = contrastColor(color);

  if (url) {
    const valid = validateUrl(url);
    if (valid) {
      hint.textContent = '✓ URL válida — ícone de link aparecerá na tag';
      hint.className = 'url-hint url-hint-ok';
    } else {
      hint.textContent = '✕ URL inválida';
      hint.className = 'url-hint url-hint-err';
    }
  } else {
    hint.textContent = '';
    hint.className = 'url-hint';
  }
}

['tag-name','tag-color','tag-url'].forEach(id => {
  document.getElementById(id)?.addEventListener('input', updatePreview);
});
updatePreview();

// ── Create tag ────────────────────────────────────────────────

document.getElementById('btn-create-tag').addEventListener('click', () => {
  const name  = document.getElementById('tag-name').value.trim();
  const color = document.getElementById('tag-color').value;
  const rawUrl = document.getElementById('tag-url').value.trim();

  if (!name) { document.getElementById('tag-name').focus(); return; }

  const url = rawUrl ? (validateUrl(rawUrl) || '') : '';

  chrome.storage.local.get(PALETTE_KEY, r => {
    const palette = r[PALETTE_KEY] || [];
    palette.push({ id: Date.now().toString(36), name, color, url });
    chrome.storage.local.set({ [PALETTE_KEY]: palette }, () => {
      document.getElementById('tag-name').value  = '';
      document.getElementById('tag-url').value   = '';
      document.getElementById('url-hint').textContent = '';
      document.getElementById('url-hint').className   = 'url-hint';
      document.querySelectorAll('.color-dot').forEach(d => d.classList.remove('selected'));
      updatePreview();
      renderPalette();
    });
  });
});

// ── Palette ───────────────────────────────────────────────────

function renderPalette() {
  chrome.storage.local.get(PALETTE_KEY, r => {
    const palette = r[PALETTE_KEY] || [];
    const list = document.getElementById('palette-list');
    if (!palette.length) {
      list.innerHTML = '<span class="empty-msg">Nenhuma tag criada ainda.</span>';
      return;
    }
    list.innerHTML = '';
    palette.forEach(tag => {
      const row = document.createElement('div');
      row.className = 'palette-item-row';

      const chip = document.createElement('span');
      chip.className = 'palette-tag-chip';
      chip.style.backgroundColor = tag.color;
      chip.style.color = contrastColor(tag.color);
      chip.innerHTML = (tag.emoji ? tag.emoji + ' ' : '') + tag.name +
        (tag.url ? ` <span class="palette-link-icon"><svg xmlns="http://www.w3.org/2000/svg" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg></span>` : '');

      const meta = document.createElement('span');
      meta.className = 'palette-item-meta';
      meta.textContent = tag.url ? '🔗 ' + tag.url.replace(/^https?:\/\//, '').slice(0, 30) : '';

      const actions = document.createElement('div');
      actions.className = 'palette-item-actions';

      const editBtn = document.createElement('button');
      editBtn.className = 'palette-action-btn';
      editBtn.title = 'Editar';
      editBtn.textContent = '✏️';
      editBtn.addEventListener('click', () => editTag(tag));

      const delBtn = document.createElement('button');
      delBtn.className = 'palette-action-btn';
      delBtn.title = 'Excluir';
      delBtn.textContent = '🗑';
      delBtn.addEventListener('click', () => deleteTag(tag.id));

      actions.append(editBtn, delBtn);
      row.append(chip, meta, actions);
      list.appendChild(row);
    });
  });
}

function editTag(tag) {
  document.getElementById('tag-name').value  = tag.name;
  document.getElementById('tag-color').value = tag.color;
  document.getElementById('tag-url').value   = tag.url || '';
  updatePreview();
  document.getElementById('tag-name').focus();

  // Replace create button temporarily
  const btn = document.getElementById('btn-create-tag');
  const original = btn.textContent;
  btn.textContent = '💾 Salvar alterações';
  btn.style.background = '#16a34a';

  function restoreBtn() {
    btn.textContent = original;
    btn.style.background = '';
    btn.onclick = null;
  }

  btn.onclick = (ev) => {
    ev.stopPropagation();
    const name  = document.getElementById('tag-name').value.trim();
    const color = document.getElementById('tag-color').value;
    const rawUrl = document.getElementById('tag-url').value.trim();
    if (!name) return;
    const url = rawUrl ? (validateUrl(rawUrl) || '') : '';

    chrome.storage.local.get(PALETTE_KEY, r => {
      const palette = r[PALETTE_KEY] || [];
      const idx = palette.findIndex(t => t.id === tag.id);
      if (idx !== -1) palette[idx] = { ...palette[idx], name, color, url };
      chrome.storage.local.set({ [PALETTE_KEY]: palette }, () => {
        document.getElementById('tag-name').value  = '';
        document.getElementById('tag-url').value   = '';
        updatePreview();
        renderPalette();
        restoreBtn();
      });
    });
  };
}

function deleteTag(id) {
  if (!confirm('Excluir esta tag da paleta? Ela continuará nos processos já tagueados.')) return;
  chrome.storage.local.get(PALETTE_KEY, r => {
    const palette = (r[PALETTE_KEY] || []).filter(t => t.id !== id);
    chrome.storage.local.set({ [PALETTE_KEY]: palette }, renderPalette);
  });
}

renderPalette();

// ── Dados ─────────────────────────────────────────────────────

let dadosActiveFilter = null;

function renderDados() {
  chrome.storage.local.get([STORAGE_KEY, PALETTE_KEY, REUS_KEY], r => {
    const allData  = r[STORAGE_KEY] || {};
    const reusData = r[REUS_KEY]    || {};
    const list = document.getElementById('dados-list');
    list.innerHTML = '';

    // ── Seção 1: Processos com tag ────────────────────────────────
    let procEntries = Object.entries(allData).filter(([,e]) => (e.tags||[]).length > 0);
    if (dadosActiveFilter)
      procEntries = procEntries.filter(([,e]) => (e.tags||[]).some(t => t.id === dadosActiveFilter.id));
    procEntries.sort(([,a],[,b]) => (b.updatedAt||'').localeCompare(a.updatedAt||''));

    const secProc = document.createElement('div');
    secProc.className = 'dado-section';
    const titleProc = document.createElement('div');
    titleProc.className = 'dado-section-title';
    titleProc.innerHTML = '<span>🏷 Processos tagueados</span><span class="dado-reu-data">' + procEntries.length + '</span>';
    secProc.appendChild(titleProc);

    if (!procEntries.length) {
      const em = document.createElement('span');
      em.className = 'empty-msg';
      em.textContent = 'Nenhum processo tagueado' + (dadosActiveFilter ? ' com esta tag' : '') + '.';
      secProc.appendChild(em);
    } else {
      procEntries.forEach(([cnj, e]) => {
        const row = document.createElement('div');
        row.className = 'dado-processo-row';

        const num = document.createElement('div');
        num.className = 'dado-processo-num';
        num.textContent = cnj;

        const tagsRow = document.createElement('div');
        tagsRow.className = 'dado-tags-row';
        (e.tags || []).forEach(tag => {
          const sp = document.createElement('span');
          sp.className = 'dado-mini-tag';
          sp.style.backgroundColor = tag.color;
          sp.style.color = contrastColor(tag.color);
          sp.textContent = (tag.emoji ? tag.emoji + ' ' : '') + tag.name;
          tagsRow.appendChild(sp);
        });

        row.appendChild(num);
        if (e.partes) {
          const partes = document.createElement('div');
          partes.className = 'dado-processo-partes';
          partes.textContent = e.partes;
          row.appendChild(partes);
        }
        row.appendChild(tagsRow);
        secProc.appendChild(row);
      });
    }
    list.appendChild(secProc);

    // ── Seção 2: Réus com tag ─────────────────────────────────────
    const reuItems = [];
    for (const [cnj, reus] of Object.entries(reusData)) {
      for (const [reuNome, entry] of Object.entries(reus)) {
        if (!(entry.tags||[]).length) continue;
        if (dadosActiveFilter && !(entry.tags||[]).some(t => t.id === dadosActiveFilter.id)) continue;
        reuItems.push({ cnj, nome: reuNome, tags: entry.tags, url: entry.url||'', dataInicio: entry.dataInicio||'' });
      }
    }

    const secReu = document.createElement('div');
    secReu.className = 'dado-section';
    secReu.style.marginTop = '10px';
    const titleReu = document.createElement('div');
    titleReu.className = 'dado-section-title';
    titleReu.innerHTML = '<span>👤 Réus tagueados</span><span class="dado-reu-data">' + reuItems.length + '</span>';
    secReu.appendChild(titleReu);

    if (!reuItems.length) {
      const em = document.createElement('span');
      em.className = 'empty-msg';
      em.textContent = 'Nenhum réu tagueado' + (dadosActiveFilter ? ' com esta tag' : '') + '.';
      secReu.appendChild(em);
    } else {
      reuItems.forEach(item => {
        const row = document.createElement('div');
        row.className = 'dado-processo-row';

        const nome = document.createElement('div');
        nome.className = 'dado-processo-partes';
        nome.style.fontWeight = '700';
        nome.style.color = '#1a1a2e';
        nome.textContent = item.nome;

        const cnjEl = document.createElement('div');
        cnjEl.className = 'dado-processo-num';
        cnjEl.style.fontSize = '10px';
        cnjEl.style.opacity = '0.7';
        cnjEl.textContent = item.cnj;

        const tagsRow = document.createElement('div');
        tagsRow.className = 'dado-tags-row';
        (item.tags || []).forEach(tag => {
          const sp = document.createElement('span');
          sp.className = 'dado-mini-tag';
          sp.style.backgroundColor = tag.color;
          sp.style.color = contrastColor(tag.color);
          sp.textContent = (tag.emoji ? tag.emoji + ' ' : '') + tag.name;
          tagsRow.appendChild(sp);
        });

        row.appendChild(nome);
        row.appendChild(cnjEl);
        row.appendChild(tagsRow);
        secReu.appendChild(row);
      });
    }
    list.appendChild(secReu);
  });
}

// Filter input
const filterInput = document.getElementById('dados-filter-input');
const filterSuggestions = document.getElementById('dados-filter-suggestions');
const filterActive = document.getElementById('dados-filter-active');
const filterLabel  = document.getElementById('dados-filter-label');
const filterClear  = document.getElementById('dados-filter-clear');

filterInput.addEventListener('input', () => {
  const q = filterInput.value.trim().toLowerCase();
  chrome.storage.local.get(PALETTE_KEY, r => {
    const palette = r[PALETTE_KEY] || [];
    const matches = palette.filter(t => t.name.toLowerCase().includes(q) || (t.emoji||'').includes(q));
    if (!q || !matches.length) { filterSuggestions.style.display = 'none'; return; }
    filterSuggestions.innerHTML = '';
    filterSuggestions.style.display = 'block';
    matches.forEach(tag => {
      const btn = document.createElement('button');
      btn.className = 'dados-filter-suggestion-item';
      btn.style.borderLeftColor = tag.color;
      btn.innerHTML = `<span class="dados-filter-dot" style="background:${tag.color}"></span>${tag.emoji||''}${tag.name}`;
      btn.addEventListener('click', () => {
        dadosActiveFilter = tag;
        filterInput.value = '';
        filterSuggestions.style.display = 'none';
        filterActive.style.display = 'flex';
        filterLabel.innerHTML = `<span class="dados-filter-dot" style="background:${tag.color};display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:5px;flex-shrink:0"></span>${tag.emoji||''}${tag.name}`;
        renderDados();
      });
      filterSuggestions.appendChild(btn);
    });
  });
});

filterClear.addEventListener('click', () => {
  dadosActiveFilter = null;
  filterActive.style.display = 'none';
  filterInput.value = '';
  renderDados();
});

document.addEventListener('click', ev => {
  if (!filterSuggestions.contains(ev.target) && ev.target !== filterInput)
    filterSuggestions.style.display = 'none';
});

// ── Prazos ────────────────────────────────────────────────────

function renderPrazos() {
  chrome.storage.local.get([REUS_KEY, STORAGE_KEY], r => {
    const reusData = r[REUS_KEY] || {};
    const allData  = r[STORAGE_KEY] || {};

    const itens = [];

    // Collect all counters
    for (const [cnj, reus] of Object.entries(reusData)) {
      for (const [reuKey, entry] of Object.entries(reus)) {
        if (!entry.dataInicio) continue;
        const dias = diasDecorridos(entry.dataInicio);
        const partes = allData[cnj]?.partes || '';
        itens.push({
          cnj,
          nome: reuKey,
          dataInicio: entry.dataInicio,
          limite: entry.limite || null,
          dias,
          partes,
        });
      }
    }

    const expirados = itens.filter(i => i.limite && i.dias >= i.limite);
    const ativos    = itens.filter(i => !(i.limite && i.dias >= i.limite));

    // Badge
    const badge    = document.getElementById('prazos-badge');
    const countBdg = document.getElementById('prazos-count-badge');
    if (expirados.length > 0) {
      badge.textContent = expirados.length;
      badge.style.display = 'inline-flex';
      countBdg.textContent = expirados.length + ' expirado' + (expirados.length !== 1 ? 's' : '');
      countBdg.style.display = 'inline-flex';
    } else {
      badge.style.display = 'none';
      countBdg.style.display = 'none';
    }

    // Expirados
    const expList = document.getElementById('prazos-expirados-list');
    if (!expirados.length) {
      expList.innerHTML = '<span class="empty-msg">Nenhum contador expirado.</span>';
    } else {
      expList.innerHTML = '';
      expirados.sort((a,b) => b.dias - a.dias).forEach(item => {
        expList.appendChild(buildPrazoRow(item, true));
      });
    }

    // Ativos
    const ativosList = document.getElementById('prazos-ativos-list');
    if (!ativos.length) {
      ativosList.innerHTML = '<span class="empty-msg">Nenhum contador ativo.</span>';
    } else {
      ativosList.innerHTML = '';
      ativos.sort((a,b) => b.dias - a.dias).forEach(item => {
        ativosList.appendChild(buildPrazoRow(item, false));
      });
    }
  });
}

function buildPrazoRow(item, isExpirado) {
  const row = document.createElement('div');
  row.className = 'prazo-item-row' + (isExpirado ? ' expirado' : '');

  const nome = document.createElement('div');
  nome.className = 'prazo-nome';
  nome.textContent = item.nome;

  const cnj = document.createElement('div');
  cnj.className = 'prazo-cnj';
  cnj.textContent = item.cnj;

  const infoRow = document.createElement('div');
  infoRow.className = 'prazo-info-row';

  const diasBadge = document.createElement('span');
  diasBadge.className = 'prazo-dias-badge' + (isExpirado ? ' expirado' : '');
  diasBadge.textContent = `⏱ ${item.dias}d decorridos`;

  infoRow.appendChild(diasBadge);

  if (item.limite) {
    const limBadge = document.createElement('span');
    limBadge.className = 'prazo-limite-badge';
    limBadge.textContent = `Limite: ${item.limite}d`;
    infoRow.appendChild(limBadge);
  }

  const dataSpan = document.createElement('span');
  dataSpan.className = 'prazo-data-inicio';
  dataSpan.textContent = 'Início: ' + item.dataInicio.slice(0,10);
  infoRow.appendChild(dataSpan);

  row.append(nome, cnj, infoRow);
  return row;
}

// Update prazos badge on load
chrome.storage.local.get([REUS_KEY], r => {
  const reusData = r[REUS_KEY] || {};
  let expCount = 0;
  for (const reus of Object.values(reusData)) {
    for (const entry of Object.values(reus)) {
      if (entry.dataInicio && entry.limite) {
        const dias = diasDecorridos(entry.dataInicio);
        if (dias >= entry.limite) expCount++;
      }
    }
  }
  const badge = document.getElementById('prazos-badge');
  if (expCount > 0) { badge.textContent = expCount; badge.style.display = 'inline-flex'; }
});

// ── Export / Import ──────────────────────────────────────────

document.getElementById('btn-export').addEventListener('click', () => {
  chrome.storage.local.get([STORAGE_KEY, PALETTE_KEY, REUS_KEY], r => {
    const data = {
      version: '4.0',
      exportedAt: new Date().toISOString(),
      tags: r[STORAGE_KEY] || {},
      palette: r[PALETTE_KEY] || [],
      reus: r[REUS_KEY] || {},
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url;
    a.download = `willtag-backup-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  });
});

document.getElementById('btn-import').addEventListener('change', ev => {
  const file = ev.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try {
      const data = JSON.parse(e.target.result);
      if (!data.tags && !data.palette) { alert('Arquivo inválido.'); return; }
      if (!confirm('Importar dados? Os dados atuais serão substituídos.')) return;

      const toSave = {};
      if (data.tags)    toSave[STORAGE_KEY]  = data.tags;
      if (data.palette) toSave[PALETTE_KEY]  = data.palette;
      if (data.reus)    toSave[REUS_KEY]     = data.reus;

      chrome.storage.local.set(toSave, () => {
        alert('Importado com sucesso!');
        renderPalette();
        renderDados();
      });
    } catch { alert('Erro ao ler o arquivo JSON.'); }
  };
  reader.readAsText(file);
  ev.target.value = '';
});

document.getElementById('btn-clear-all').addEventListener('click', () => {
  if (!confirm('Apagar TODOS os dados (tags, processos e contadores)?')) return;
  chrome.storage.local.remove([STORAGE_KEY, PALETTE_KEY, REUS_KEY], () => {
    renderPalette();
    renderDados();
    renderPrazos();
    alert('Dados apagados.');
  });
});
