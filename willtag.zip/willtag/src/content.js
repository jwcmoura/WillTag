// ============================================================
// Willtag · Organização Visual | content.js  v4.0
// Alterações v4.0:
//  - Contador de dias: opções rápidas 5/15/30/90 dias + campo data
//  - Contadores expirados aparecem na aba "Prazos" do popup
//  - Polo ativo: seletor preciso via getElementById('poloAtivo')
//  - Sem duplicatas de [+] e tags no polo passivo/ativo
//  - Filtro por tag injetado em <th> da classe rich-table-subheadercell
//  - Nome: Organização Visual - Willtag (sem TJPB)
// ============================================================

(function () {
  'use strict';

  const STORAGE_KEY     = 'pjeTags_v3';
  const STORAGE_KEY_V2  = 'pjeTags_v2';
  const PALETTE_KEY     = 'pjeTags_palette';
  const ENABLED_KEY     = 'pjeTags_enabled';
  const REUS_KEY        = 'pjeTags_reus';
  const INJECTED_ATTR   = 'data-pjetags-injected';
  const INJECTED_REU    = 'data-pjetags-reu';
  const CONTAINER_CLASS = 'pjetags-container';
  const FILTER_ID       = 'pjetags-tag-filter';

  const PROCESS_REGEX = /\d{7}-\d{2}\.\d{4}\.\d\.\d{2}\.\d{4}/;

  let allData              = {};
  let reusData             = {};
  let currentAcervo        = '';
  let isEnabled            = true;
  let acervoActiveFilter   = null;

  // ── Storage ──────────────────────────────────────────────────

  function loadData(cb) {
    chrome.storage.local.get([STORAGE_KEY, STORAGE_KEY_V2, ENABLED_KEY, REUS_KEY], (r) => {
      isEnabled = r[ENABLED_KEY] !== false;
      if (!r[STORAGE_KEY] && r[STORAGE_KEY_V2]) {
        allData = migrateV2toV3(r[STORAGE_KEY_V2]);
        chrome.storage.local.set({ [STORAGE_KEY]: allData });
      } else {
        allData = r[STORAGE_KEY] || {};
      }
      reusData = r[REUS_KEY] || {};
      cb && cb();
    });
  }

  function saveData(cb)     { chrome.storage.local.set({ [STORAGE_KEY]: allData }, cb); }
  function saveReusData(cb) { chrome.storage.local.set({ [REUS_KEY]: reusData }, cb); }

  function migrateV2toV3(v2) {
    const v3 = {}, partes = v2['__partes__'] || {};
    for (const [ac, procs] of Object.entries(v2)) {
      if (ac === '__partes__') continue;
      for (const [cnj, tags] of Object.entries(procs)) {
        if (!cnj.match(PROCESS_REGEX)) continue;
        v3[cnj] = { tags: tags||[], acervo: ac, partes: partes[cnj]||'', updatedAt: new Date().toISOString() };
      }
    }
    return v3;
  }

  // ── Utilitários ──────────────────────────────────────────────

  function extractCNJ(t)  { const m=(t||'').match(PROCESS_REGEX); return m?m[0]:null; }
  function reuKey(n)       { return (n||'').trim().toUpperCase(); }

  function contrastColor(hex) {
    const r=parseInt(hex.slice(1,3),16), g=parseInt(hex.slice(3,5),16), b=parseInt(hex.slice(5,7),16);
    return ((0.299*r+0.587*g+0.114*b)/255)>0.55?'#1a1a2e':'#ffffff';
  }

  function diasDecorridos(dataInicio) {
    if (!dataInicio) return null;
    const a=new Date(dataInicio), b=new Date();
    a.setHours(0,0,0,0); b.setHours(0,0,0,0);
    return Math.floor((b-a)/86400000);
  }

  // ── SVGs ─────────────────────────────────────────────────────

  function svgLink(size=10, color='currentColor') {
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24"
      fill="none" stroke="${color}" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"
      style="display:inline-block;vertical-align:middle;flex-shrink:0">
      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>
      <polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
    </svg>`;
  }

  function svgCopy(size=11) {
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 24 24"
      fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"
      style="display:inline-block;vertical-align:middle">
      <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
    </svg>`;
  }

  // ── Detecção de contexto ──────────────────────────────────────

  function detectAcervo() {
    for (const td of document.querySelectorAll('td.rich-tree-node-selected,td.rich-tree-node-highlighted,.rich-tree-node-selected,.rich-tree-node-highlighted')) {
      const lj=td.querySelector('a[title="Jurisdição"]');
      if (lj) { const sp=lj.querySelector('span.nomeTarefa'); const t=(sp||lj); const tx=(t.innerText||t.textContent).trim(); if(tx.length>3) return tx; }
      const nt=td.querySelector('span.nomeTarefa'); if(nt){const tx=(nt.innerText||nt.textContent).trim();if(tx.length>3)return tx;}
    }
    for (const el of document.querySelectorAll('a[title="Jurisdição"] span.nomeTarefa')) { const t=(el.innerText||el.textContent).trim(); if(t.length>3)return t; }
    for (const el of document.querySelectorAll('span.nomeTarefa')) { const t=(el.innerText||el.textContent).trim(); if(t.length>8&&!/^caixa/i.test(t))return t; }
    return 'Acervo Desconhecido';
  }

  function isPageDeAutos() {
    return /\/(Processo|processo|autos)\//i.test(window.location.href) ||
      !!document.querySelector('.processo-cabecalho,.painel-autos,[class*="cabecalho-processo"]');
  }

  function detectProcessoNosAutos() {
    let m=document.title.match(PROCESS_REGEX); if(m)return m[0];
    for(const el of document.querySelectorAll('h1,h2,.processo-numero,[class*="numero-processo"],.titulo-processo,header a,.cabecalho-processo')){m=(el.innerText||el.textContent||'').match(PROCESS_REGEX);if(m)return m[0];}
    for(const el of document.querySelectorAll('span.text-bold,span[class*="bold"]')){const r=extractCNJ(el.innerText||el.textContent||'');if(r)return r;}
    for(const el of document.querySelectorAll('body > div > *,main > *')){m=(el.innerText||el.textContent||'').match(PROCESS_REGEX);if(m)return m[0];}
    return null;
  }

  function detectPartesNosAutos() {
    for(const sel of ['.nome-partes,.partes-processo,[class*="partes"]','.subtitulo-processo,.processo-partes','header .partes,.cabecalho .partes']){const el=document.querySelector(sel);if(el){const t=(el.innerText||el.textContent).trim();if(t.length>5)return t;}}
    const hz=document.querySelector('header,.painel-autos > div:first-child,body > div:first-child');
    if(hz){for(const el of hz.querySelectorAll('span,div,p,small')){const t=(el.innerText||el.textContent||'').trim();if(/^[A-ZÁÉÍÓÚÃÕÂÊÔÀÜ\s]+ X [A-ZÁÉÍÓÚÃÕÂÊÔÀÜ\s]+$/.test(t)&&t.length>10)return t;}}
    return '';
  }

  function detectPartesNaLista(rowEl) {
    const np=rowEl.querySelector('.nome-parte'); if(np)return(np.innerText||np.textContent).trim();
    const id=rowEl.querySelector('.informacoes-linha-acervo,.col-md-8');
    if(id){for(const d of id.querySelectorAll('div,span')){const t=(d.innerText||d.textContent).trim();if(t.length>5&&!PROCESS_REGEX.test(t)&&!/^\d/.test(t))return t;}}
    return '';
  }

  // ── Google Calendar ──────────────────────────────────────────

  function buildCalendarUrl(processo, tag, partes) {
    const lbl=(tag.emoji?tag.emoji+' ':'')+tag.name;
    let det=`Processo: ${processo}`;
    if(partes) det+=`\nPartes: ${partes}`;
    det+=`\nTag: ${lbl}`;
    return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent('['+lbl+'] '+processo)}&details=${encodeURIComponent(det)}`;
  }

  // ══════════════════════════════════════════════════════════════
  // ── BOTÃO "+" URL (fica ANTES do nome) ───────────────────────
  // ══════════════════════════════════════════════════════════════

  function getReuEntry(cnj, nome) {
    const k=reuKey(nome);
    if(!reusData[cnj]) reusData[cnj]={};
    if(!reusData[cnj][k]) reusData[cnj][k]={tags:[],dataInicio:'',url:'',limite:null};
    return reusData[cnj][k];
  }

  function buildSobreBtn(cnj, nome, onRefresh) {
    const holder=document.createElement('span');
    holder.className='pjetags-sobre-holder';

    function render() {
      holder.innerHTML='';
      const e=getReuEntry(cnj,nome);

      if (e.url) {
        const a=document.createElement('a');
        a.className='pjetags-sobre-link'; a.href=e.url; a.target='_blank'; a.rel='noopener noreferrer';
        a.title=`Abrir: ${e.url}`; a.innerHTML=svgLink(12,'#1a6db5');
        a.addEventListener('click',ev=>ev.stopPropagation());
        holder.appendChild(a);
        const rm=document.createElement('button');
        rm.className='pjetags-sobre-remove'; rm.title='Remover link'; rm.textContent='✕';
        rm.addEventListener('click',ev=>{ev.stopPropagation();ev.preventDefault();
          const k=reuKey(nome); if(reusData[cnj]&&reusData[cnj][k]) reusData[cnj][k].url='';
          saveReusData(()=>render());
        });
        holder.appendChild(rm);
      } else {
        const btn=document.createElement('button');
        btn.className='pjetags-sobre-add'; btn.title='Adicionar link para esta pessoa'; btn.textContent='+';
        btn.addEventListener('click',ev=>{ev.stopPropagation();ev.preventDefault();openSobreForm(btn,cnj,nome,render);});
        holder.appendChild(btn);
      }
    }

    render();
    return holder;
  }

  function openSobreForm(anchor, cnj, nome, onSaved) {
    document.querySelectorAll('.pjetags-sobre-form').forEach(f=>f.remove());
    const form=document.createElement('div');
    form.className='pjetags-sobre-form pjetags-menu'; form.style.minWidth='280px';
    form.innerHTML=`
      <div class="pjetags-menu-header">${svgLink(13,'#0f4c81')}<strong style="margin-left:4px">Link para esta pessoa</strong></div>
      <div class="pjetags-menu-processo" style="margin-bottom:8px">${nome}</div>
      <input type="text" class="pjetags-sobre-url-input" placeholder="https://..."
        style="width:100%;padding:6px 8px;border:1px solid #dde1e7;border-radius:6px;font-size:12px;
               font-family:inherit;outline:none;transition:border-color 0.15s;box-sizing:border-box;" autocomplete="off">
      <span class="pjetags-sobre-url-hint" style="display:block;font-size:10px;min-height:14px;margin:2px 0 6px;font-weight:600;"></span>
      <div style="display:flex;gap:6px">
        <button class="pjetags-picker-item pjetags-sobre-save" style="flex:1;border-left:3px solid #0f4c81">✓ Salvar</button>
        <button class="pjetags-picker-item pjetags-sobre-cancel" style="flex:1;border-left:3px solid #aaa">✕ Cancelar</button>
      </div>`;
    const rect=anchor.getBoundingClientRect();
    form.style.top=`${rect.bottom+window.scrollY+4}px`;
    form.style.left=`${rect.left+window.scrollX}px`;
    document.body.appendChild(form);
    const inp=form.querySelector('.pjetags-sobre-url-input');
    const hint=form.querySelector('.pjetags-sobre-url-hint');
    inp.focus();

    function validateUrl(raw) {
      if(!raw.trim()) return null;
      let u=raw.trim(); if(!/^https?:\/\//i.test(u)) u='https://'+u;
      try{new URL(u);return u;}catch{return null;}
    }

    inp.addEventListener('input',()=>{
      const v=validateUrl(inp.value);
      if(!inp.value.trim()){hint.textContent='';return;}
      hint.textContent=v?'✓ URL válida':'✕ URL inválida';
      hint.style.color=v?'#16a34a':'#c0392b';
      inp.style.borderColor=v?'#16a34a':'#f44336';
    });

    form.querySelector('.pjetags-sobre-save').addEventListener('click',ev=>{
      ev.stopPropagation();
      const url=validateUrl(inp.value); if(!url){inp.style.borderColor='#f44336';inp.focus();return;}
      const k=reuKey(nome);
      if(!reusData[cnj]) reusData[cnj]={};
      if(!reusData[cnj][k]) reusData[cnj][k]={tags:[],dataInicio:'',url:'',limite:null};
      reusData[cnj][k].url=url;
      saveReusData(()=>{form.remove();onSaved&&onSaved();});
    });

    form.querySelector('.pjetags-sobre-cancel').addEventListener('click',ev=>{ev.stopPropagation();form.remove();});
    setTimeout(()=>{document.addEventListener('click',function c(ev){if(!form.contains(ev.target)){form.remove();document.removeEventListener('click',c);}});},60);
  }

  // ══════════════════════════════════════════════════════════════
  // ── BOTÃO COPIAR (fica DEPOIS do nome) ───────────────────────
  // ══════════════════════════════════════════════════════════════

  function buildCopyBtn(nome) {
    const btn=document.createElement('button');
    btn.className='pjetags-copy-btn'; btn.title=`Copiar: ${nome}`; btn.innerHTML=svgCopy(11);
    btn.setAttribute('aria-label','Copiar nome');
    btn.addEventListener('mouseenter',()=>{btn.style.opacity='1';btn.style.background='#e8f0fe';btn.style.color='#1a3a6b';});
    btn.addEventListener('mouseleave',()=>{if(!btn.dataset.copied){btn.style.opacity='0.55';btn.style.background='transparent';btn.style.color='#555';}});
    btn.addEventListener('click',ev=>{
      ev.stopPropagation();ev.preventDefault();
      navigator.clipboard.writeText(nome).then(()=>{
        btn.dataset.copied='1'; const orig=btn.innerHTML;
        btn.innerHTML='<span style="font-size:11px;font-weight:700;color:#16a34a">✓</span>';
        btn.style.opacity='1';btn.style.background='#dcfce7';btn.style.borderColor='#86efac';btn.title='Copiado!';
        setTimeout(()=>{delete btn.dataset.copied;btn.innerHTML=orig;btn.style.opacity='0.55';btn.style.background='transparent';btn.style.borderColor='rgba(0,0,0,0.15)';btn.title=`Copiar: ${nome}`;},1500);
      }).catch(()=>{const ta=document.createElement('textarea');ta.value=nome;ta.style.cssText='position:fixed;top:-9999px';document.body.appendChild(ta);ta.select();document.execCommand('copy');ta.remove();});
    });
    return btn;
  }

  // ══════════════════════════════════════════════════════════════
  // ── CONTAINER DO RÉU ─────────────────────────────────────────
  //
  // Ordem: [+URL]  NOME_ORIGINAL  [copiar]  [+tag]  TAGS  [⏱Xd]
  //
  // ANTI-DUPLICATA: usa INJECTED_REU no spanPai como guard.
  // renderAfter() recria o conteúdo do "after" por completo,
  // sem re-append de novos elementos — apenas innerHTML='' + rebuild.
  // ══════════════════════════════════════════════════════════════

  function buildReuWrap(cnj, nome, spanPai) {
    // [before] vai ANTES do spanPai — contém apenas o botão "+ URL"
    const before=document.createElement('span');
    before.className='pjetags-reu-wrap pjetags-reu-before';
    before.setAttribute('data-reu-key', reuKey(nome));
    before.appendChild(buildSobreBtn(cnj, nome, renderAfter));

    // [after] vai APÓS o spanPai — contém copiar + [+tag] + tags + contador
    const after=document.createElement('span');
    after.className='pjetags-reu-wrap pjetags-reu-after';
    after.setAttribute('data-reu-key', reuKey(nome));

    function renderAfter() {
      // Limpa completamente antes de re-renderizar
      after.innerHTML='';
      const entry=getReuEntry(cnj, nome);

      // [copiar]
      after.appendChild(buildCopyBtn(nome));

      // [+ tag]
      const addBtn=document.createElement('button');
      addBtn.className='pjetags-add-btn pjetags-reu-add';
      addBtn.title='Adicionar tag / definir data';
      addBtn.textContent='+';
      addBtn.addEventListener('click',ev=>{ev.stopPropagation();ev.preventDefault();openReuPopup(cnj,nome,after,renderAfter);});
      after.appendChild(addBtn);

      // Tags
      (entry.tags||[]).forEach(tag=>{
        const sp=document.createElement('span');
        sp.className='pjetag-label pjetag-reu-label';
        sp.style.backgroundColor=tag.color; sp.style.color=contrastColor(tag.color);
        sp.style.display='inline-flex'; sp.style.alignItems='center'; sp.style.gap='3px';
        sp.title=tag.url?`${tag.name} · Clique para abrir link`:tag.name;

        const body=document.createElement('span');
        body.textContent=(tag.emoji?tag.emoji+' ':'')+tag.name;
        sp.appendChild(body);

        if(tag.url){
          const lb=document.createElement('span'); lb.className='pjetag-link-icon'; lb.title=`Abrir: ${tag.url}`; lb.innerHTML=svgLink(10,contrastColor(tag.color));
          lb.style.cssText='display:inline-flex;align-items:center;cursor:pointer;padding:0 1px;opacity:0.75;border-radius:3px;transition:opacity 0.15s,background 0.15s;margin-left:1px;';
          lb.addEventListener('mouseenter',()=>{lb.style.opacity='1';lb.style.background='rgba(0,0,0,0.12)';});
          lb.addEventListener('mouseleave',()=>{lb.style.opacity='0.75';lb.style.background='transparent';});
          lb.addEventListener('click',ev=>{ev.stopPropagation();ev.preventDefault();window.open(tag.url,'_blank','noopener,noreferrer');});
          sp.appendChild(lb);
        }

        sp.addEventListener('click',ev=>{ev.stopPropagation();ev.preventDefault();showReuTagMenu(sp,tag,cnj,nome,renderAfter);});
        after.appendChild(sp);
      });

      // Contador (só se tiver data)
      if (entry.dataInicio) {
        const dias=diasDecorridos(entry.dataInicio);
        const limite=entry.limite||null;
        const expirado=limite&&dias>=limite;
        const cnt=document.createElement('span');
        cnt.className='pjetags-contador'+(expirado?' pjetags-contador-expirado':'');
        cnt.style.cursor='pointer';
        cnt.textContent=`⏱ ${dias}d`;
        cnt.title=`${dias} dia${dias!==1?'s':''} decorridos`+(limite?` · limite: ${limite}d`:'');
        if(expirado){cnt.style.background='#fee2e2';cnt.style.borderColor='#fca5a5';cnt.style.color='#c0392b';}
        cnt.addEventListener('click',ev=>{ev.stopPropagation();openDatePicker(cnj,nome,cnt,renderAfter);});
        after.appendChild(cnt);
      }
    }

    renderAfter();
    return { before, after, renderAfter };
  }

  /** Injeta os dois wraps (before/after) em torno de spanPai — sem duplicatas */
  function injectOneReu(cnj, nome, spanPai) {
    // Guard primário: se já injetamos neste elemento, não duplica
    if (spanPai.getAttribute(INJECTED_REU)) return;
    // Guard secundário: se o td pai já contém um wrap para este réu, não duplica
    const tdPai = spanPai.closest('td');
    if (tdPai && tdPai.querySelector(`.pjetags-reu-after[data-reu-key="${reuKey(nome)}"]`)) return;
    spanPai.setAttribute(INJECTED_REU, reuKey(nome));

    const parent = spanPai.parentNode;
    if (!parent) return;

    const { before, after } = buildReuWrap(cnj, nome, spanPai);
    parent.insertBefore(before, spanPai);
    parent.insertBefore(after, spanPai.nextSibling);
  }

  // ── Popup "+" do réu: tags + contador com opções rápidas ─────

  function openReuPopup(cnj, nome, anchor, renderAfter) {
    document.querySelectorAll('.pjetags-inline-popup').forEach(p=>p.remove());
    chrome.storage.local.get(PALETTE_KEY, res=>{
      const palette=res[PALETTE_KEY]||[];
      const entry=getReuEntry(cnj,nome);
      const popup=document.createElement('div');
      popup.className='pjetags-inline-popup pjetags-popup-centered';
      popup.style.position='fixed'; popup.style.top='50%'; popup.style.left='50%';
      popup.style.transform='translate(-50%,-50%)'; popup.style.minWidth='420px'; popup.style.maxWidth='90vw';

      const applied=new Set((entry.tags||[]).map(t=>t.id));

      function renderReuGrid(filter) {
        const q=(filter||'').toLowerCase().trim();
        const visible=q?palette.filter(t=>t.name.toLowerCase().includes(q)):palette;
        if(!visible.length) return '<span class="pjetags-no-palette">Nenhuma tag encontrada.</span>';
        return visible.map(t=>{const ap=applied.has(t.id);const lm=t.url?` ${svgLink(9,contrastColor(t.color))}`:'';return`<button class="pjetags-palette-item${ap?' aplicada':''}" data-tagid="${t.id}" style="background:${t.color};color:${contrastColor(t.color)}" title="${ap?'Já aplicada':(t.url?'🔗 '+t.url:'Aplicar tag')}">${t.name}${lm}${ap?' ✓':''}</button>`;}).join('');
      }

      const reuSearchHtml=palette.length>1?`<div style="margin-bottom:8px;"><input type="text" class="pjetags-tag-search" placeholder="🔍 Buscar tag..." autocomplete="off" style="width:100%;padding:6px 10px;border:1px solid #dde1e7;border-radius:6px;font-size:12px;font-family:inherit;outline:none;box-sizing:border-box;"></div>`:'';
      const pHtml=palette.length>0?renderReuGrid(''):'<span class="pjetags-no-palette">Nenhuma tag criada ainda.</span>';

      const dataAtual=entry.dataInicio?entry.dataInicio.slice(0,10):'';
      const diasAtual=diasDecorridos(entry.dataInicio);
      const contadorInfo=diasAtual!==null?`<span style="font-size:10px;color:#1a3a6b;font-weight:600;margin-left:6px">⏱ ${diasAtual}d decorridos</span>`:'';
      const limiteAtual=entry.limite||'';

      popup.innerHTML=`
        <div class="pjetags-popup-title">🏷 ${nome}<button class="pjetags-popup-close">✕</button></div>
        ${reuSearchHtml}<div class="pjetags-palette-grid">${pHtml}</div>
        <div style="border-top:1px solid #f0f0f0;padding-top:8px;margin-top:4px">
          <div style="font-size:10px;font-weight:700;color:#6b7280;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:5px">📅 Contador de dias</div>
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
            <input type="date" id="pjetags-reu-date" value="${dataAtual}"
              style="flex:1;padding:5px 7px;border:1px solid #dde1e7;border-radius:6px;font-size:12px;font-family:inherit;outline:none;cursor:pointer;">
            ${contadorInfo}
          </div>
          <div style="font-size:10px;font-weight:600;color:#6b7280;margin-bottom:4px">Limite (dias):</div>
          <div style="display:flex;gap:5px;margin-bottom:6px" id="pjetags-limite-btns">
            ${[5,15,30,90].map(n=>`<button class="pjetags-limite-opt${limiteAtual==n?' ativo':''}" data-limite="${n}"
              style="flex:1;padding:4px 0;border:1px solid ${limiteAtual==n?'#1a73e8':'#dde1e7'};background:${limiteAtual==n?'#e8f0fe':'#fafbfc'};
              border-radius:5px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;color:${limiteAtual==n?'#1a3a6b':'#555'};
              transition:all 0.15s;">${n}d</button>`).join('')}
            <button class="pjetags-limite-opt${!limiteAtual?' ativo':''}" data-limite=""
              style="flex:1;padding:4px 0;border:1px solid ${!limiteAtual?'#f44336':'#dde1e7'};background:${!limiteAtual?'#fee2e2':'#fafbfc'};
              border-radius:5px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;color:${!limiteAtual?'#c0392b':'#555'};
              transition:all 0.15s;">✕</button>
          </div>
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
            <input type="number" id="pjetags-limite-custom" min="1" max="9999" placeholder="Ou digite os dias..."
              value="${limiteAtual&&![5,15,30,90].includes(Number(limiteAtual))?limiteAtual:''}"
              style="flex:1;padding:5px 8px;border:1px solid #dde1e7;border-radius:6px;font-size:12px;font-family:inherit;outline:none;box-sizing:border-box;">
            <span style="font-size:10px;color:#6b7280;white-space:nowrap">dias</span>
          </div>
          <div style="display:flex;gap:5px">
            <button class="pjetags-picker-item pjetags-date-save" style="flex:1;border-left:3px solid #1a73e8">✓ Salvar</button>
            ${dataAtual?'<button class="pjetags-picker-item pjetags-date-clear" style="flex:1;border-left:3px solid #f44336">✕ Limpar data</button>':''}
          </div>
        </div>`;

      document.body.appendChild(popup);
      popup.querySelector('.pjetags-popup-close').addEventListener('click',()=>popup.remove());

      const reuSearchEl=popup.querySelector('.pjetags-tag-search');
      if(reuSearchEl) {
        reuSearchEl.addEventListener('input',()=>{
          popup.querySelector('.pjetags-palette-grid').innerHTML=renderReuGrid(reuSearchEl.value);
          bindReuGridClicks();
        });
      }

      // Seletor de limite
      let selectedLimite = limiteAtual ? String(limiteAtual) : '';
      popup.querySelectorAll('.pjetags-limite-opt').forEach(btn=>{
        btn.addEventListener('click',ev=>{
          ev.stopPropagation();
          selectedLimite=btn.getAttribute('data-limite');
          popup.querySelector('#pjetags-limite-custom').value='';
          popup.querySelectorAll('.pjetags-limite-opt').forEach(b=>{
            const isSel=b.getAttribute('data-limite')===selectedLimite;
            const isRed=b.getAttribute('data-limite')==='';
            b.style.borderColor=isSel?(isRed?'#f44336':'#1a73e8'):'#dde1e7';
            b.style.background=isSel?(isRed?'#fee2e2':'#e8f0fe'):'#fafbfc';
            b.style.color=isSel?(isRed?'#c0392b':'#1a3a6b'):'#555';
          });
        });
      });
      const customInput=popup.querySelector('#pjetags-limite-custom');
      if(customInput) customInput.addEventListener('input',()=>{
        if(customInput.value.trim()){
          selectedLimite=customInput.value.trim();
          popup.querySelectorAll('.pjetags-limite-opt').forEach(b=>{b.style.borderColor='#dde1e7';b.style.background='#fafbfc';b.style.color='#555';});
        }
      });

      // Tags
      function bindReuGridClicks() {
        popup.querySelectorAll('.pjetags-palette-item:not(.aplicada)').forEach(btn=>{
          btn.addEventListener('click',ev=>{ev.stopPropagation();
            const tagId=(ev.target.closest('[data-tagid]')||btn).getAttribute('data-tagid');
            const tag=palette.find(t=>t.id===tagId); if(!tag) return;
            const e2=getReuEntry(cnj,nome); if(!e2.tags.some(t=>t.id===tag.id)) e2.tags.push(tag);
            saveReusData(()=>{renderAfter();popup.remove();});
          });
        });
      }
      bindReuGridClicks();

      // Salvar data + limite
      popup.querySelector('.pjetags-date-save').addEventListener('click',ev=>{
        ev.stopPropagation();
        const v=popup.querySelector('#pjetags-reu-date').value; if(!v) return;
        const k=reuKey(nome);
        reusData[cnj]=reusData[cnj]||{}; reusData[cnj][k]=reusData[cnj][k]||{tags:[],dataInicio:'',url:'',limite:null};
        reusData[cnj][k].dataInicio=v;
        reusData[cnj][k].limite=selectedLimite?parseInt(selectedLimite,10):null;
        saveReusData(()=>{renderAfter();popup.remove();});
      });

      // Limpar data
      const clrBtn=popup.querySelector('.pjetags-date-clear');
      if(clrBtn) clrBtn.addEventListener('click',ev=>{ev.stopPropagation();
        const k=reuKey(nome); if(reusData[cnj]&&reusData[cnj][k]){reusData[cnj][k].dataInicio='';reusData[cnj][k].limite=null;}
        saveReusData(()=>{renderAfter();popup.remove();});
      });

      setTimeout(()=>{document.addEventListener('click',function c(ev){if(!popup.contains(ev.target)){popup.remove();document.removeEventListener('click',c);}});},60);
    });
  }

  function showReuTagMenu(anchor, tag, cnj, nome, renderAfter) {
    document.querySelectorAll('.pjetags-menu').forEach(m=>m.remove());
    const menu=document.createElement('div'); menu.className='pjetags-menu';
    const lh=tag.url?`<a href="${tag.url}" target="_blank" rel="noopener noreferrer" class="pjetags-btn-link" style="display:flex;align-items:center;justify-content:center;gap:5px;background:#f0f4ff;border:1px solid #c5d5f7;color:#1a3a6b;text-decoration:none;padding:7px 12px;border-radius:6px;font-size:12px;font-weight:700;margin-bottom:6px;">${svgLink(11,'#1a3a6b')} Abrir link vinculado</a>`:'';
    menu.innerHTML=`<div class="pjetags-menu-header"><span class="pjetags-menu-dot" style="background:${tag.color}"></span><strong>${tag.emoji||'🏷'} ${tag.name}</strong></div><div class="pjetags-menu-processo">${nome}</div><div class="pjetags-menu-actions">${lh}<button class="pjetags-btn-remove">🗑 Remover esta tag</button></div>`;
    const rect=anchor.getBoundingClientRect();
    menu.style.top=`${rect.bottom+window.scrollY+4}px`; menu.style.left=`${rect.left+window.scrollX}px`;
    document.body.appendChild(menu);
    menu.querySelector('.pjetags-btn-remove').addEventListener('click',()=>{
      const e=getReuEntry(cnj,nome); e.tags=e.tags.filter(t=>t.id!==tag.id);
      saveReusData(()=>{renderAfter();menu.remove();});
    });
    setTimeout(()=>{document.addEventListener('click',function c(ev){if(!menu.contains(ev.target)){menu.remove();document.removeEventListener('click',c);}});},50);
  }

  function openDatePicker(cnj, nome, anchor, renderAfter) {
    document.querySelectorAll('.pjetags-reu-date-picker').forEach(p=>p.remove());
    const entry=getReuEntry(cnj,nome);
    const picker=document.createElement('div'); picker.className='pjetags-reu-date-picker';
    const rect=anchor.getBoundingClientRect();
    picker.style.top=`${rect.bottom+window.scrollY+4}px`; picker.style.left=`${rect.left+window.scrollX}px`;
    const da=entry.dataInicio?entry.dataInicio.slice(0,10):'';
    const limiteAtual=entry.limite||'';
    picker.innerHTML=`
      <div class="pjetags-picker-title">📅 Contador — ${nome}</div>
      <input type="date" class="pjetags-date-input" value="${da}">
      <div style="font-size:10px;font-weight:600;color:#6b7280;margin:6px 0 4px">Limite:</div>
      <div style="display:flex;gap:5px;margin-bottom:6px" id="pjetags-picker-limite-btns">
        ${[5,15,30,90].map(n=>`<button class="pjetags-limite-opt${limiteAtual==n?' ativo':''}" data-limite="${n}"
          style="flex:1;padding:4px 0;border:1px solid ${limiteAtual==n?'#1a73e8':'#dde1e7'};background:${limiteAtual==n?'#e8f0fe':'#fafbfc'};
          border-radius:5px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;color:${limiteAtual==n?'#1a3a6b':'#555'};
          transition:all 0.15s;">${n}d</button>`).join('')}
        <button class="pjetags-limite-opt${!limiteAtual?' ativo':''}" data-limite=""
          style="flex:1;padding:4px 0;border:1px solid ${!limiteAtual?'#f44336':'#dde1e7'};background:${!limiteAtual?'#fee2e2':'#fafbfc'};
          border-radius:5px;font-size:11px;font-weight:700;cursor:pointer;font-family:inherit;color:${!limiteAtual?'#c0392b':'#555'};
          transition:all 0.15s;">✕</button>
      </div>
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:6px">
        <input type="number" id="pjetags-picker-limite-custom" min="1" max="9999" placeholder="Ou digite os dias..."
          value="${limiteAtual&&![5,15,30,90].includes(Number(limiteAtual))?limiteAtual:''}"
          style="flex:1;padding:5px 8px;border:1px solid #dde1e7;border-radius:6px;font-size:12px;font-family:inherit;outline:none;box-sizing:border-box;">
        <span style="font-size:10px;color:#6b7280;white-space:nowrap">dias</span>
      </div>
      <div style="display:flex;gap:6px">
        <button class="pjetags-picker-item pjetags-date-ok" style="flex:1;border-left:3px solid #1a73e8">✓ Salvar</button>
        ${da?'<button class="pjetags-picker-item pjetags-date-clear" style="flex:1;border-left:3px solid #f44336">✕ Limpar</button>':''}
      </div>`;
    document.body.appendChild(picker);

    let selectedLimite = limiteAtual ? String(limiteAtual) : '';
    picker.querySelectorAll('.pjetags-limite-opt').forEach(btn=>{
      btn.addEventListener('click',ev=>{
        ev.stopPropagation();
        selectedLimite=btn.getAttribute('data-limite');
        picker.querySelector('#pjetags-picker-limite-custom').value='';
        picker.querySelectorAll('.pjetags-limite-opt').forEach(b=>{
          const isSel=b.getAttribute('data-limite')===selectedLimite;
          const isRed=b.getAttribute('data-limite')==='';
          b.style.borderColor=isSel?(isRed?'#f44336':'#1a73e8'):'#dde1e7';
          b.style.background=isSel?(isRed?'#fee2e2':'#e8f0fe'):'#fafbfc';
          b.style.color=isSel?(isRed?'#c0392b':'#1a3a6b'):'#555';
        });
      });
    });
    const pickerCustom=picker.querySelector('#pjetags-picker-limite-custom');
    if(pickerCustom) pickerCustom.addEventListener('input',()=>{
      if(pickerCustom.value.trim()){
        selectedLimite=pickerCustom.value.trim();
        picker.querySelectorAll('.pjetags-limite-opt').forEach(b=>{b.style.borderColor='#dde1e7';b.style.background='#fafbfc';b.style.color='#555';});
      }
    });

    picker.querySelector('.pjetags-date-ok').addEventListener('click',ev=>{
      ev.stopPropagation();
      const v=picker.querySelector('.pjetags-date-input').value; if(!v)return;
      const k=reuKey(nome);
      reusData[cnj]=reusData[cnj]||{}; reusData[cnj][k]=reusData[cnj][k]||{tags:[],dataInicio:'',url:'',limite:null};
      reusData[cnj][k].dataInicio=v;
      reusData[cnj][k].limite=selectedLimite?parseInt(selectedLimite,10):null;
      saveReusData(()=>{renderAfter();picker.remove();});
    });

    const cb=picker.querySelector('.pjetags-date-clear');
    if(cb) cb.addEventListener('click',ev=>{
      ev.stopPropagation();
      const k=reuKey(nome);
      if(reusData[cnj]&&reusData[cnj][k]){reusData[cnj][k].dataInicio='';reusData[cnj][k].limite=null;}
      saveReusData(()=>{renderAfter();picker.remove();});
    });

    setTimeout(()=>{document.addEventListener('click',function c(ev){if(!picker.contains(ev.target)){picker.remove();document.removeEventListener('click',c);}});},50);
  }

  // ══════════════════════════════════════════════════════════════
  // ── INJEÇÃO NO POLO PASSIVO ───────────────────────────────────
  // td > span (direto) — mesmo padrão do polo ativo
  // ══════════════════════════════════════════════════════════════

  function injectPoloPassivo(cnj) {
    const polo=document.getElementById('poloPassivo'); if(!polo) return;
    polo.querySelectorAll('td').forEach(td=>{
      // Pega apenas o span direto do td que representa o nome — evita spans aninhados
      const spans=[...td.querySelectorAll(':scope > span')];
      const spanPai=spans.length>0 ? spans[0] : null;
      if(!spanPai) return;
      const nome=(spanPai.innerText||spanPai.textContent).trim();
      if(!nome||nome.length<3||PROCESS_REGEX.test(nome)) return;
      injectOneReu(cnj, nome, spanPai);
    });
  }

  // ══════════════════════════════════════════════════════════════
  // ── INJEÇÃO NO POLO ATIVO ─────────────────────────────────────
  // Seletor preciso via getElementById('poloAtivo') > td > span
  // ══════════════════════════════════════════════════════════════

  function injectPoloAtivo(cnj) {
    const polo=document.getElementById('poloAtivo'); if(!polo) return;
    polo.querySelectorAll('td').forEach(td=>{
      // Pega apenas o span direto do td — evita spans aninhados/filhos
      const spans=[...td.querySelectorAll(':scope > span')];
      const spanPai=spans.length>0 ? spans[0] : null;
      if(!spanPai) return;
      const nome=(spanPai.innerText||spanPai.textContent).trim();
      if(!nome||nome.length<3||PROCESS_REGEX.test(nome)) return;
      injectOneReu(cnj, nome, spanPai);
    });
  }

  // ══════════════════════════════════════════════════════════════
  // ── FILTRO POR TAG — injetado em <th> da tabela do acervo ────
  //
  // Injeta um novo <th> com o botão "▽ Tags" logo após o th que
  // contém "Processos" na classe rich-table-subheadercell.
  // Compatível com o screenshot: thead.rich-table-thead > tr > th.rich-table-subheadercell
  // ══════════════════════════════════════════════════════════════

  function injectAcervoTagFilter() {
    if(document.getElementById(FILTER_ID)) return;
    const thead=document.querySelector('thead.rich-table-thead'); if(!thead) return;

    const ths=[...thead.querySelectorAll('th.rich-table-subheadercell')];
    if(!ths.length) return;

    // Cria um novo <th> para o filtro, inserido como último na linha
    const filterTh=document.createElement('th');
    filterTh.className='rich-table-subheadercell';
    filterTh.id=FILTER_ID;
    filterTh.style.cssText='padding:2px 6px;vertical-align:middle;white-space:nowrap;';

    const wrapper=document.createElement('span');
    wrapper.style.cssText='display:inline-flex;align-items:center;gap:4px;position:relative;';

    const btn=document.createElement('button');
    btn.className='pjetags-acervo-filter-btn';
    btn.title='Filtrar por tag';
    btn.innerHTML=`<svg xmlns="http://www.w3.org/2000/svg" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg><span class="pjetags-acervo-filter-label">Tags</span>`;
    wrapper.appendChild(btn);
    filterTh.appendChild(wrapper);

    // Insere o th na linha do thead
    const tr=ths[0].closest('tr');
    if(tr) tr.appendChild(filterTh);

    btn.addEventListener('click',ev=>{ev.stopPropagation();toggleFilterDropdown(btn,wrapper);});
  }

  function toggleFilterDropdown(anchor, wrapper) {
    const ex=document.getElementById('pjetags-acervo-dropdown'); if(ex){ex.remove();return;}
    chrome.storage.local.get(PALETTE_KEY,res=>{
      const palette=res[PALETTE_KEY]||[];
      const dd=document.createElement('div'); dd.id='pjetags-acervo-dropdown';
      dd.style.cssText='position:absolute;top:calc(100% + 4px);left:0;background:#fff;border:1px solid #dde1e7;border-radius:10px;box-shadow:0 8px 28px rgba(0,0,0,0.16);padding:10px;z-index:999999;min-width:200px;font-family:"Segoe UI",system-ui,sans-serif;animation:pjetags-fadein 0.12s ease;';

      const title=document.createElement('div');
      title.style.cssText='font-size:11px;font-weight:700;color:#0f4c81;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px;padding-bottom:5px;border-bottom:1px solid #f0f0f0;';
      title.textContent='🏷 Filtrar por tag'; dd.appendChild(title);

      if(palette.length===0){
        const em=document.createElement('div'); em.style.cssText='font-size:11px;color:#888;font-style:italic;'; em.textContent='Nenhuma tag criada ainda.'; dd.appendChild(em);
      } else {
        const allBtn=document.createElement('button'); allBtn.className='pjetags-picker-item'; allBtn.style.borderLeftColor='#aaa'; allBtn.style.marginBottom='4px'; allBtn.textContent='✕ Mostrar todos';
        allBtn.addEventListener('click',ev=>{ev.stopPropagation();acervoActiveFilter=null;applyAcervoFilter();updateFilterBtn(null);dd.remove();});
        dd.appendChild(allBtn);

        palette.forEach(tag=>{
          const item=document.createElement('button'); item.className='pjetags-picker-item'; item.style.borderLeftColor=tag.color;
          if(acervoActiveFilter&&acervoActiveFilter.id===tag.id){item.style.background='#e8f0fe';item.style.fontWeight='900';}
          item.innerHTML=`<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${tag.color};margin-right:5px;flex-shrink:0"></span>${tag.emoji||''}${tag.name}`;
          item.addEventListener('click',ev=>{ev.stopPropagation();acervoActiveFilter=tag;applyAcervoFilter();updateFilterBtn(tag);dd.remove();});
          dd.appendChild(item);
        });
      }

      wrapper.style.position='relative'; wrapper.appendChild(dd);
      setTimeout(()=>{document.addEventListener('click',function c(ev){if(!dd.contains(ev.target)){dd.remove();document.removeEventListener('click',c);}});},50);
    });
  }

  function applyAcervoFilter() {
    const fid=acervoActiveFilter?acervoActiveFilter.id:null;
    document.querySelectorAll('tbody tr.rich-table-row,tbody tr[class*="rich-table-row"]').forEach(row=>{
      if(!fid){row.style.display='';return;}
      let cnj=null; for(const el of row.querySelectorAll('a,span,td')){cnj=extractCNJ(el.innerText||el.textContent||'');if(cnj)break;}
      if(!cnj){row.style.display='';return;}
      row.style.display=(allData[cnj]&&(allData[cnj].tags||[]).some(t=>t.id===fid))?'':'none';
    });
    document.querySelectorAll(`.${CONTAINER_CLASS}[data-processo]`).forEach(c=>{
      const cnj=c.getAttribute('data-processo'); if(!fid){c.style.display='';return;}
      c.style.display=(allData[cnj]&&(allData[cnj].tags||[]).some(t=>t.id===fid))?'':'none';
    });
  }

  function updateFilterBtn(tag) {
    const btn=document.querySelector(`#${FILTER_ID} .pjetags-acervo-filter-btn`); if(!btn) return;
    const lbl=btn.querySelector('.pjetags-acervo-filter-label');
    if(tag){btn.style.background=tag.color;btn.style.borderColor=tag.color;btn.style.color=contrastColor(tag.color);if(lbl)lbl.textContent=(tag.emoji?tag.emoji+' ':'')+tag.name;}
    else{btn.style.background='';btn.style.borderColor='';btn.style.color='';if(lbl)lbl.textContent='Tags';}
  }

  // ── Tags de processo ──────────────────────────────────────────

  function createTagElement(tag, cnj, acervo, partes) {
    const wrap=document.createElement('span'); wrap.className='pjetag-label';
    wrap.style.backgroundColor=tag.color; wrap.style.color=contrastColor(tag.color);
    wrap.style.display='inline-flex'; wrap.style.alignItems='center'; wrap.style.gap='3px';

    const body=document.createElement('span'); body.className='pjetag-label-body'; body.style.cursor='pointer';
    body.textContent=(tag.emoji?tag.emoji+' ':'')+tag.name;
    body.addEventListener('click',ev=>{ev.stopPropagation();ev.preventDefault();showTagMenu(wrap,tag,cnj,acervo,partes);});
    wrap.appendChild(body);

    if(tag.url){
      const lb=document.createElement('span'); lb.className='pjetag-link-icon'; lb.title=`Abrir: ${tag.url}`; lb.innerHTML=svgLink(10,contrastColor(tag.color));
      lb.style.cssText='display:inline-flex;align-items:center;cursor:pointer;padding:0 1px;opacity:0.75;border-radius:3px;transition:opacity 0.15s,background 0.15s;margin-left:1px;';
      lb.addEventListener('mouseenter',()=>{lb.style.opacity='1';lb.style.background='rgba(0,0,0,0.12)';});
      lb.addEventListener('mouseleave',()=>{lb.style.opacity='0.75';lb.style.background='transparent';});
      lb.addEventListener('click',ev=>{ev.stopPropagation();ev.preventDefault();window.open(tag.url,'_blank','noopener,noreferrer');});
      wrap.appendChild(lb);
    }
    return wrap;
  }

  function createCalendarBtn(cnj, acervo, partes, tags) {
    const btn=document.createElement('button'); btn.className='pjetags-cal-icon-btn'; btn.title='Adicionar ao Google Calendar'; btn.innerHTML='📅';
    btn.addEventListener('click',ev=>{ev.stopPropagation();ev.preventDefault();
      if(tags.length===0) window.open(buildCalendarUrl(cnj,{name:'Lembrete',emoji:'📌'},partes),'_blank');
      else if(tags.length===1) window.open(buildCalendarUrl(cnj,tags[0],partes),'_blank');
      else showCalendarPicker(btn,cnj,partes,tags);
    });
    return btn;
  }

  function showCalendarPicker(anchor, cnj, partes, tags) {
    document.querySelectorAll('.pjetags-cal-picker').forEach(m=>m.remove());
    const p=document.createElement('div'); p.className='pjetags-cal-picker';
    const r=anchor.getBoundingClientRect(); p.style.top=`${r.bottom+scrollY+4}px`; p.style.left=`${r.left+scrollX}px`;
    p.innerHTML='<div class="pjetags-picker-title">📅 Adicionar ao calendário</div><div class="pjetags-picker-sub">Selecione a tag:</div>';
    tags.forEach(tag=>{const b=document.createElement('button');b.className='pjetags-picker-item';b.style.borderLeftColor=tag.color;b.textContent=(tag.emoji?tag.emoji+' ':'')+tag.name;b.addEventListener('click',ev=>{ev.stopPropagation();window.open(buildCalendarUrl(cnj,tag,partes),'_blank');p.remove();});p.appendChild(b);});
    const gb=document.createElement('button');gb.className='pjetags-picker-item';gb.style.borderLeftColor='#999';gb.textContent='📌 Lembrete genérico';gb.addEventListener('click',ev=>{ev.stopPropagation();window.open(buildCalendarUrl(cnj,{name:'Lembrete',emoji:'📌'},partes),'_blank');p.remove();});p.appendChild(gb);
    document.body.appendChild(p);
    setTimeout(()=>{document.addEventListener('click',function c(){p.remove();document.removeEventListener('click',c);});},50);
  }

  function showTagMenu(anchor, tag, cnj, acervo, partes) {
    document.querySelectorAll('.pjetags-menu').forEach(m=>m.remove());
    const menu=document.createElement('div'); menu.className='pjetags-menu';
    const calUrl=buildCalendarUrl(cnj,tag,partes);
    const lh=tag.url?`<a href="${tag.url}" target="_blank" rel="noopener noreferrer" class="pjetags-btn-link" style="display:flex;align-items:center;justify-content:center;gap:5px;background:#f0f4ff;border:1px solid #c5d5f7;color:#1a3a6b;text-decoration:none;padding:7px 12px;border-radius:6px;font-size:12px;font-weight:700;margin-bottom:6px;">${svgLink(11,'#1a3a6b')} Abrir link vinculado</a>`:''
    menu.innerHTML=`<div class="pjetags-menu-header"><span class="pjetags-menu-dot" style="background:${tag.color}"></span><strong>${tag.emoji||'🏷'} ${tag.name}</strong></div><div class="pjetags-menu-processo">${cnj}</div>${partes?`<div class="pjetags-menu-partes">👥 ${partes}</div>`:''}<div class="pjetags-menu-actions">${lh}<a href="${calUrl}" target="_blank" class="pjetags-btn-cal">📅 Adicionar ao Calendário</a><button class="pjetags-btn-remove">🗑 Remover esta tag</button></div>`;
    const rect=anchor.getBoundingClientRect(); menu.style.top=`${rect.bottom+scrollY+4}px`; menu.style.left=`${rect.left+scrollX}px`;
    document.body.appendChild(menu);
    menu.querySelector('.pjetags-btn-remove').addEventListener('click',()=>{removeTag(cnj,tag.id);menu.remove();});
    setTimeout(()=>{document.addEventListener('click',function c(ev){if(!menu.contains(ev.target)){menu.remove();document.removeEventListener('click',c);}});},50);
  }

  // ── Container de processo ─────────────────────────────────────

  function buildContainer(cnj) {
    const entry=allData[cnj]||{}, tags=entry.tags||[], acervo=entry.acervo||currentAcervo||'Acervo Desconhecido', partes=entry.partes||'';
    const container=document.createElement('div'); container.className=CONTAINER_CLASS;
    container.setAttribute('data-processo',cnj); container.setAttribute('data-acervo',acervo);

    const addBtn=document.createElement('button'); addBtn.className='pjetags-add-btn'; addBtn.title='Adicionar tag'; addBtn.textContent='+';
    addBtn.addEventListener('click',ev=>{ev.stopPropagation();ev.preventDefault();openAddTagPopup(cnj,container);});
    container.appendChild(addBtn);
    tags.forEach(t=>container.appendChild(createTagElement(t,cnj,acervo,partes)));
    container.appendChild(createCalendarBtn(cnj,acervo,partes,tags));

    if(acervoActiveFilter) container.style.display=(tags.some(t=>t.id===acervoActiveFilter.id))?'':'none';
    return container;
  }

  function openAddTagPopup(cnj, container) {
    document.querySelectorAll('.pjetags-inline-popup').forEach(p=>p.remove());
    chrome.storage.local.get(PALETTE_KEY,res=>{
      const palette=res[PALETTE_KEY]||[], entry=allData[cnj]||{}, partes=entry.partes||'';
      const popup=document.createElement('div'); popup.className='pjetags-inline-popup pjetags-popup-centered';
      popup.style.position='fixed'; popup.style.top='50%'; popup.style.left='50%';
      popup.style.transform='translate(-50%,-50%)'; popup.style.minWidth='420px'; popup.style.maxWidth='90vw';
      const applied=new Set((entry.tags||[]).map(t=>t.id));

      function renderGrid(filter) {
        const q=(filter||'').toLowerCase().trim();
        const visible=q?palette.filter(t=>t.name.toLowerCase().includes(q)):palette;
        if(!visible.length) return '<span class="pjetags-no-palette">Nenhuma tag encontrada.</span>';
        return visible.map(t=>{const ap=applied.has(t.id);const lm=t.url?` ${svgLink(9,contrastColor(t.color))}`:'';return`<button class="pjetags-palette-item${ap?' aplicada':''}" data-tagid="${t.id}" style="background:${t.color};color:${contrastColor(t.color)}" title="${ap?'Já aplicada':(t.url?'🔗 '+t.url:'Aplicar tag')}">${t.name}${lm}${ap?' ✓':''}</button>`;}).join('');
      }

      const searchHtml=palette.length>1?`<div style="margin-bottom:8px;position:relative;"><input type="text" class="pjetags-tag-search" placeholder="🔍 Buscar tag..." autocomplete="off" style="width:100%;padding:6px 10px;border:1px solid #dde1e7;border-radius:6px;font-size:12px;font-family:inherit;outline:none;box-sizing:border-box;"></div>`:'';

      popup.innerHTML=`<div class="pjetags-popup-title">🏷 Adicionar tag ao processo<button class="pjetags-popup-close">✕</button></div><div class="pjetags-popup-processo">${cnj}</div>${partes?`<div class="pjetags-popup-partes">👥 ${partes}</div>`:''} ${searchHtml}<div class="pjetags-palette-grid">${palette.length>0?renderGrid(''):'<span class="pjetags-no-palette">Nenhuma tag criada ainda.</span>'}</div>`;
      document.body.appendChild(popup);
      popup.querySelector('.pjetags-popup-close').addEventListener('click',()=>popup.remove());

      const searchEl=popup.querySelector('.pjetags-tag-search');
      if(searchEl) {
        searchEl.addEventListener('input',()=>{
          popup.querySelector('.pjetags-palette-grid').innerHTML=renderGrid(searchEl.value);
          bindGridClicks();
        });
        searchEl.focus();
      }

      function bindGridClicks() {
        popup.querySelectorAll('.pjetags-palette-item:not(.aplicada)').forEach(btn=>{btn.addEventListener('click',ev=>{ev.stopPropagation();const tag=palette.find(t=>t.id===btn.getAttribute('data-tagid'));if(tag){addTagToProcess(cnj,tag);popup.remove();}});});
      }
      bindGridClicks();

      setTimeout(()=>{document.addEventListener('click',function c(ev){if(!popup.contains(ev.target)){popup.remove();document.removeEventListener('click',c);}});},60);
    });
  }

  // ── CRUD processo ─────────────────────────────────────────────

  function addTagToProcess(cnj, tag) {
    if(!allData[cnj]) allData[cnj]={tags:[],acervo:currentAcervo,partes:'',updatedAt:''};
    if(currentAcervo&&currentAcervo!=='Acervo Desconhecido') allData[cnj].acervo=currentAcervo;
    if(!allData[cnj].tags.some(t=>t.id===tag.id)) allData[cnj].tags.push(tag);
    allData[cnj].updatedAt=new Date().toISOString();
    saveData(()=>refreshProcess(cnj));
  }

  function removeTag(cnj, tagId) {
    if(!allData[cnj]) return;
    allData[cnj].tags=allData[cnj].tags.filter(t=>t.id!==tagId);
    allData[cnj].updatedAt=new Date().toISOString();
    saveData(()=>refreshProcess(cnj));
  }

  function updatePartesIfNeeded(cnj, partes) {
    if(!partes) return;
    if(!allData[cnj]) allData[cnj]={tags:[],acervo:currentAcervo,partes:'',updatedAt:''};
    if(!allData[cnj].partes){allData[cnj].partes=partes;saveData();}
  }

  function refreshProcess(cnj) {
    document.querySelectorAll(`[${INJECTED_ATTR}="${cnj}"]`).forEach(el=>el.removeAttribute(INJECTED_ATTR));
    document.querySelectorAll(`.${CONTAINER_CLASS}[data-processo="${cnj}"]`).forEach(c=>c.remove());
    // Limpa os wraps do réu associados ao processo
    document.querySelectorAll('.pjetags-reu-before,.pjetags-reu-after').forEach(w=>{
      // Apenas remove se estiver dentro de um polo do processo atual
      const polo=w.closest('#poloPassivo,#poloAtivo');
      if(polo){
        const spanMarcado=polo.querySelector(`[${INJECTED_REU}]`);
        if(spanMarcado) spanMarcado.removeAttribute(INJECTED_REU);
        w.remove();
      }
    });
    scanAndInject();
  }

  // ── Timeline search ───────────────────────────────────────────

  const SEARCH_BAR_ID='pjetags-timeline-searchbar', HIGHLIGHT_MARK='pjetags-hl-mark';

  function clearHighlights(){document.querySelectorAll('.pjetags-hl').forEach(el=>el.classList.remove('pjetags-hl'));document.querySelectorAll(`.${HIGHLIGHT_MARK}`).forEach(m=>{const p=m.parentNode;if(p){p.replaceChild(document.createTextNode(m.textContent),m);p.normalize();}});}

  function highlightText(root,q){if(!q||!root)return 0;const lq=q.toLowerCase();let cnt=0;const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,{acceptNode(n){const p=n.parentElement;if(!p)return NodeFilter.FILTER_REJECT;if(p.closest(`.${CONTAINER_CLASS}`)||p.closest('.pjetags-menu')||p.closest('.pjetags-inline-popup')||p.closest(`#${SEARCH_BAR_ID}`))return NodeFilter.FILTER_REJECT;return NodeFilter.FILTER_ACCEPT;}});const ns=[];let n;while((n=w.nextNode()))if(n.nodeValue.toLowerCase().includes(lq))ns.push(n);for(const tn of ns){const txt=tn.nodeValue,lt=txt.toLowerCase(),par=tn.parentNode;if(!par)continue;const f=document.createDocumentFragment();let l=0,i=lt.indexOf(lq,l);while(i!==-1){if(i>l)f.appendChild(document.createTextNode(txt.slice(l,i)));const m=document.createElement('mark');m.className=HIGHLIGHT_MARK;m.textContent=txt.slice(i,i+q.length);f.appendChild(m);cnt++;l=i+q.length;i=lt.indexOf(lq,l);}if(l<txt.length)f.appendChild(document.createTextNode(txt.slice(l)));par.replaceChild(f,tn);(par.closest('tr,li,div,p,td,span')||par).classList.add('pjetags-hl');}return cnt;}

  function injectTimelineSearchBar(){if(document.getElementById(SEARCH_BAR_ID))return;const anchor=document.querySelector('div.nesautsa.affiy-ton[data-spy="affiy"]');if(!anchor)return;const bar=document.createElement('div');bar.id=SEARCH_BAR_ID;bar.innerHTML=`<div class="pjetags-search-inner"><span class="pjetags-search-ico">🔍</span><input type="text" class="pjetags-search-input" placeholder="Buscar no histórico do processo..." autocomplete="off" spellcheck="false"><span class="pjetags-search-count" id="pjetags-search-count"></span><button class="pjetags-search-clear" id="pjetags-search-clear" title="Limpar busca">✕</button></div>`;anchor.parentNode.insertBefore(bar,anchor.nextSibling);const inp=bar.querySelector('.pjetags-search-input'),ce=bar.querySelector('#pjetags-search-count'),cl=bar.querySelector('#pjetags-search-clear');function gr(){let s=bar.nextElementSibling;while(s){if(!s.classList.contains(CONTAINER_CLASS)&&!s.id?.startsWith('pjetags'))return s;s=s.nextElementSibling;}return anchor.parentNode;}let dt=null;inp.addEventListener('input',()=>{clearTimeout(dt);dt=setTimeout(()=>{const q=inp.value.trim();clearHighlights();if(!q){ce.textContent='';cl.style.display='none';return;}const root=gr();const found=highlightText(root,q);ce.textContent=found>0?`${found} resultado${found!==1?'s':''}`:'Nenhum resultado';ce.style.color=found>0?'#16a34a':'#c0392b';cl.style.display='inline-flex';const fm=root.querySelector(`.${HIGHLIGHT_MARK}`);if(fm)fm.scrollIntoView({behavior:'smooth',block:'center'});},280);});cl.addEventListener('click',()=>{inp.value='';clearHighlights();ce.textContent='';cl.style.display='none';inp.focus();});cl.style.display='none';}

  // ── Navbar ────────────────────────────────────────────────────

  function injectIntoNavbar(cnj){const id=`pjetags-navbar-${cnj}`;if(document.getElementById(id))return;const nav=[document.querySelector('nav.navbar,.navbar-fixed-top,.navbar-pje'),document.querySelector('[class*="navbar"]:not(.dropdown)'),document.querySelector('header nav,header > div:first-child'),document.querySelector('.painel-cabecalho,.cabecalho-fixo')].filter(Boolean)[0];if(!nav)return;if(window.getComputedStyle(nav).position==='static')nav.style.position='relative';const partes=detectPartesNosAutos();const c=buildContainer(cnj);c.id=id;c.classList.add('pjetags-navbar-centered');updatePartesIfNeeded(cnj,partes);nav.appendChild(c);}

  function injectIntoAutos(cnj){injectIntoNavbar(cnj);injectPoloPassivo(cnj);injectPoloAtivo(cnj);injectTimelineSearchBar();}

  // ── Lista de processos ────────────────────────────────────────

  function injectIntoListRow(linkEl, cnj) {
    if(linkEl.getAttribute(INJECTED_ATTR)===cnj)return;
    linkEl.setAttribute(INJECTED_ATTR,cnj);
    linkEl.closest('td,.rich-table-cell,.vcenter')?.querySelector(`.${CONTAINER_CLASS}[data-processo="${cnj}"]`)?.remove();
    const row=linkEl.closest('tr,.rich-table-row,.vcenter,.informacoes-linha-acervo')||linkEl.parentElement;
    const partes=detectPartesNaLista(row);
    if(!allData[cnj]){allData[cnj]={tags:[],acervo:currentAcervo,partes:partes||'',updatedAt:''};saveData();}
    else{let ch=false;if(!allData[cnj].partes&&partes){allData[cnj].partes=partes;ch=true;}if(!allData[cnj].acervo&&currentAcervo){allData[cnj].acervo=currentAcervo;ch=true;}if(ch)saveData();}
    linkEl.parentNode.insertBefore(buildContainer(cnj),linkEl.nextSibling);
  }

  // ── Scanner principal ─────────────────────────────────────────

  function scanAndInject(){
    if(!isEnabled) return;
    currentAcervo=detectAcervo();

    if(isPageDeAutos()){const cnj=detectProcessoNosAutos();if(cnj)injectIntoAutos(cnj);return;}

    injectAcervoTagFilter();

    document.querySelectorAll('a[href],.rich-table-row a,td a,.informacoes-linha-acervo a,.rich-table-cell a,.painel-resultado a').forEach(link=>{
      if(link.closest(`.${CONTAINER_CLASS}`)||link.closest('.pjetags-menu'))return;
      const cnj=extractCNJ(link.innerText||link.textContent||'');if(!cnj)return;
      let ch=false;link.querySelectorAll('*').forEach(c=>{if(extractCNJ(c.innerText||c.textContent||'')===cnj)ch=true;});if(ch)return;
      injectIntoListRow(link,cnj);
    });

    document.querySelectorAll('span.text-bold,span[class*="bold"],span,td,div,label,h3,h4,p').forEach(el=>{
      if(el.closest(`.${CONTAINER_CLASS}`)||el.closest('.pjetags-menu')||el.classList.contains(CONTAINER_CLASS)||el.children.length>10)return;
      // Polo passivo/ativo são tratados exclusivamente por injectPoloPassivo/Ativo — nunca pelo scanner genérico
      if(el.closest('#poloPassivo')||el.closest('#poloAtivo'))return;
      const cnj=extractCNJ(el.innerText||el.textContent||'');if(!cnj)return;
      let ch=false;el.querySelectorAll('span,td,div,a,label').forEach(c=>{if(extractCNJ(c.innerText||c.textContent||'')===cnj)ch=true;});if(ch)return;
      if(el.getAttribute(INJECTED_ATTR)===cnj)return;
      el.setAttribute(INJECTED_ATTR,cnj);
      el.parentNode?.querySelector(`.${CONTAINER_CLASS}[data-processo="${cnj}"]`)?.remove();
      const row=el.closest('tr,.rich-table-row')||el.parentElement;
      const partes=detectPartesNaLista(row);
      if(!allData[cnj]){allData[cnj]={tags:[],acervo:currentAcervo,partes:partes||'',updatedAt:''};saveData();}
      else if(!allData[cnj].partes&&partes){allData[cnj].partes=partes;saveData();}
      el.parentNode.insertBefore(buildContainer(cnj),el.nextSibling);
    });

    if(acervoActiveFilter) applyAcervoFilter();
  }

  function removeAllContainers(){
    document.querySelectorAll(`.${CONTAINER_CLASS}`).forEach(c=>c.remove());
    document.querySelectorAll('.pjetags-reu-wrap,.pjetags-reu-before,.pjetags-reu-after').forEach(c=>c.remove());
    document.querySelectorAll(`[${INJECTED_ATTR}]`).forEach(el=>el.removeAttribute(INJECTED_ATTR));
    document.querySelectorAll(`[${INJECTED_REU}]`).forEach(el=>el.removeAttribute(INJECTED_REU));
    document.getElementById(SEARCH_BAR_ID)?.remove();
    document.getElementById(FILTER_ID)?.remove();
    document.getElementById('pjetags-acervo-dropdown')?.remove();
    clearHighlights();
    acervoActiveFilter=null;
  }

  let scanTimer=null;
  function scheduleScan(){clearTimeout(scanTimer);scanTimer=setTimeout(()=>loadData(scanAndInject),450);}

  const observer=new MutationObserver(mutations=>{
    const own=new Set([CONTAINER_CLASS,'pjetags-menu','pjetags-inline-popup','pjetags-cal-picker','pjetags-reu-wrap','pjetags-reu-before','pjetags-reu-after','pjetags-reu-date-picker',SEARCH_BAR_ID,'pjetags-sobre-form']);
    if(mutations.some(m=>[...m.addedNodes].some(n=>n.nodeType===1&&typeof(n.className||'')==='string'&&!own.has(n.className||'')&&!(n.className||'').includes('pjetags'))))scheduleScan();
  });

  chrome.runtime.onMessage.addListener((msg,_,res)=>{
    if(msg.type==='GET_CONTEXT') res({acervo:detectAcervo(),enabled:isEnabled});
    if(msg.type==='RELOAD_TAGS') loadData(scanAndInject);
    if(msg.type==='REFRESH_NOW'){removeAllContainers();loadData(scanAndInject);res({ok:true});}
    if(msg.type==='SET_ENABLED'){isEnabled=msg.value;chrome.storage.local.set({[ENABLED_KEY]:isEnabled});if(!isEnabled)removeAllContainers();else loadData(scanAndInject);res({ok:true,enabled:isEnabled});}
    if(msg.type==='GET_ENABLED') res({enabled:isEnabled});
  });

  function init(){loadData(()=>{if(isEnabled){scanAndInject();observer.observe(document.body,{childList:true,subtree:true});}});}
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init);
  else init();

})();
